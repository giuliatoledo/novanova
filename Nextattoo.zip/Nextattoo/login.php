<!DOCTYPE html>
<html lang="pt-br">
<head>

	<title>Nextattoo</title>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="fav.jpg" type="image/x-icon"/>
	<link rel="stylesheet" type="text/css" href="nextattoo.css">
	<link href="css/bootstrap.min.css" rel= stylesheet" type="text/css"/>
	<link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script type= text/javascript" src="js/bootstrap.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

<body class="body">

<?php
/*
$email= $_POST['email'];
$senha= $_POST['password'];

$emailValido = "contato@nextattoo.com.br";
$senhaValida = "1234";

if($email == $emailValido){
	if($senha == $senhaValida){
		echo "<font color='white'><h4>Dados corretos! :)</font></h4><br>";
	} else {
		echo "<font color='white'><h4>Tente novamente...<br>Senha incorreta! :( </font></h4><br>";
	}
} else {
	echo "<font color='white'><h4>Ops... e-mail inválido.</font></h4><br>";
}

*/
?>

	<!------------------------= CABEÇALHO ---------------------------------------->
<header><img class="logotipo" src="nextattologopreto.jpg"></header>

<!--------------------------------- MENU -------------------------------------->

<!-- MENU REMOTO -->
<script>
$(document).ready(function(){
	//requisição http
	let url ="http://rafaelsperoni.pro.br/tsi/menus.php?user=2018003605"
	$.getJSON(url, function(dados){
	//dados é um array com o conteúdo do json
	console.log(dados);
	for (i=0; i<8; i++){
				$("#lista-menu").append('<li><a href="'+dados[i].link+'" id="'+dados[i].titulo+'">'+dados[i].titulo+'</a></li>');
			}
});
});
</script>

<div class="colunas">	
	<div id="principal" align="center">
	<nav id="menu" align="center">
	<ul id="lista-menu">
	    </ul>
	</nav>
</div>

		<div id="pessoas">
	<!--------------------------------------- LISTAGEM DE PROFISSIONAIS ------------------------------------------>
		<div class="pessoa1"></div>
		<div class="pessoa2"></div>
		<div class="pessoa3"></div>
		<div class="pessoa4"></div>
		<div class="pessoa5"></div>
		</div>

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">

<!------------------------------------------ ANUNCIO E CHAT ---------------------------------------------->
<div id="direita">

<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>

<div id="carousel" class="carousel slide" data-ride="carousel">
	<!-- Para acionar os indicadores de slide: <ol class="carousel-indicators">
		<li data-target="#carousel" data-slide-to="0" class="active"></li>
		<li data-target="#carousel" data-slide-to="1"></li>
	</ol>
	-->

<div class="carousel-inner" role="listbox">
		<div class="item active">
			<img src="1.jpg" alt="">
		<div class="carousel-caption">
		</div>
	</div>

<div class="item">
	<img src="2.jpg" alt="">
	<div class="carousel-caption">
	</div>
</div>

	<!--<div class="anuncios"></div>
 <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="1.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="2.jpg" alt="Second slide">
    </div>
  </div>
</div>﻿
</div>
-->

<div class="chat"></div>
</div>
<!-- exibir - show()
esconder - hide()
alternar - toggle()
button#alternar gera o botão-->

<footer>
	© 2019 The Nextattoo Company, all rights reserved
</footer>

</body>
</head>
</html>