<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>Nextattoo</title>
  <link rel="shortcut icon" href="fav.jpg" type="image/x-icon"/>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css"  href="style.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <body>
    <center>
	<header><img class="logotipo" src="nxt.png"></header>

		 <?php
		// check opção escolhida
		if (isset($_POST['tatuador'])) {
		    echo "<font color='white'><h4>Bem vindo ao nosso time de tatuadores! <br>Vamos começar?</font></h4><br>";
		} else {
		    echo "<font color='white'><h4>Você está cada vez mais perto da sua #NEXTATTOO.<br>Vamos começar?</font></h4><br>";
		}	
		?>

<div class="container">
  <div class="row">
    <div class="col-sm">
     <form action="acesso.php" method="POST">
      <div class="form-group">
          <label for="exampleInputName">Nome</label>
          <input type="name" name="name" class="form-control" id="exampleInputName" aria-describedby="Name" placeholder="Seu nome" style=" width: 300px;">
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">E-mail</label>
          <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Seu email" style=" width: 300px;">
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Senha</label>
          <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Senha" style=" width: 300px;">
        </div>
        <div class="form-group form-check">
          <input type="checkbox" class="form-check-input" id="exampleCheck1">
          <label class="form-check-label" for="exampleCheck1">Lembrar Dados de Acesso</label>
        </div><br>
      <button type="submit" input class="btn btn-primary">Cadastrar</button>
      </form>
  	</div>
</div>	

</body>
</head>
</html>